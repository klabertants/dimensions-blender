import bpy

# Global state
bpy.types.Scene.is_streaming = bpy.props.BoolProperty(name="is_streaming", default=False)
timer_instance = None
