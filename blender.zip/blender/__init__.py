bl_info = {
    'name': '3DAI',
    'blender': (3, 0, 0),
    'category': 'Development',
    'version': (0, 1, 1),
    'author': '???',
    'description': '3DAI',
}

import bpy

from .main_panel import MainPanel, ViewportStreamExportOperator, ViewportSnapshotExportOperator, OpenWebInterfaceOperator, ExampleAddonPreferences

classes = (
    MainPanel,
    ViewportStreamExportOperator,
    ViewportSnapshotExportOperator,
    OpenWebInterfaceOperator,
    ExampleAddonPreferences
)

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)

def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)

if __name__ == '__main__':
    register()
