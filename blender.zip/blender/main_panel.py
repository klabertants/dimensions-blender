import bpy
from bpy.props import StringProperty, PointerProperty
from bpy.types import PropertyGroup, Operator, AddonPreferences
from . import global_state
from .bearer_auth import BearerAuth
import webbrowser
from threading import Thread
import os
import requests
from datetime import datetime

class ExampleAddonPreferences(AddonPreferences):
    # this must match the add-on name, use '__package__'
    # when defining this in a submodule of a python package.
    bl_idname = __package__

    api_token: StringProperty(
        name="API Token",
        subtype='NONE',
        maxlen=2048
    )

    def draw(self, context):
        layout = self.layout
        layout.label(text="Insert your API token from workspace below.")
        layout.prop(self, "api_token")

class MainPanel(bpy.types.Panel):
    bl_idname = '3DAI_main_panel'
    bl_label = 'ExpanseAI'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = '3DAI'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        row = layout.row()
        row.operator(
            '3dai.viewport_stream_export_operator',
            text='Start streaming' if not context.scene.is_streaming else 'Stop Streaming'
        )

        row = layout.row()
        row.operator(
            '3dai.viewport_snapshot_export_operator',
            text='Send snapshot'
        )

        row = layout.row()
        row.operator(
            '3dai.open_web_interface_operator',
            text='Open workspace'
        )


class ViewportStreamExportOperator(bpy.types.Operator):
    bl_idname = '3dai.viewport_stream_export_operator'
    bl_label = 'Viewport Stream Exporter'
    cur_frame = 0

    @classmethod
    def description(cls, context, properties):
        return "In progress"

    @classmethod
    def poll(cls, context):
        return False

    def dump_frame(self, num):
        scene = bpy.context.scene
        desktop = os.path.join(os.path.join(os.path.expanduser('~')), 'Desktop')
        stream_dir = os.path.join(desktop, "stream")
        scene.render.filepath = os.path.join(stream_dir, str(num) + ".png")
        bpy.ops.render.opengl(write_still=True)

    def private_execute(self, context):
        wm = context.window_manager

        print(f'ViewportStreamExportOperator : execute {context.scene.is_streaming}')

        if not context.scene.is_streaming:
            context.scene.is_streaming = True
            global_state.timer_instance = wm.event_timer_add(1, window=context.window)
            wm.modal_handler_add(self)
        else:
            context.scene.is_streaming = False

    def execute(self, context):
        th = Thread(target=self.private_execute(context))
        th.start()
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if not context.scene.is_streaming:
            wm = context.window_manager
            wm.event_timer_remove(global_state.timer_instance)
            global_state.timer_instance = None
            return {'FINISHED'}

        if event.type != 'TIMER':
            return {'PASS_THROUGH'}

        print('Sending frame')
        th = Thread(target=self.dump_frame(self.cur_frame))
        th.start()
        self.cur_frame += 1

        return {'PASS_THROUGH'}

class ViewportSnapshotExportOperator(bpy.types.Operator):
    bl_idname = '3dai.viewport_snapshot_export_operator'
    bl_label = 'Viewport snapshot exporter'

    @classmethod
    def poll(cls, context):
        return not context.scene.is_streaming

    @classmethod
    def description(cls, context, properties):
        return "Creates viewport snapshot and sends it to server"

    def private_execute(self, context):
        print('Sending snapshot')
        scene = context.scene
        preferences = context.preferences
        addon_prefs = preferences.addons[__package__].preferences
        desktop = os.path.join(os.path.join(os.path.expanduser('~')), 'Desktop')
        tmp_dir = os.path.join(desktop, "expanse_ai_temporary")
        now = datetime.now()
        date_time = now.strftime("%m_%d_%Y_%H_%M_%S")
        filename = "snapshot_" + date_time + ".png"
        scene.render.filepath = os.path.join(tmp_dir, filename)
        bpy.ops.render.opengl(write_still=True)

        # Define API and Input
        url = 'http://0.0.0.0:8000/asset/'
        file_path = scene.render.filepath

        # Prepare Input
        files = {'file': (filename, open(file_path, 'rb'), "image/png")}
        response = requests.post(url, files=files, auth=BearerAuth(addon_prefs.api_token))

    def execute(self, context):
        th = Thread(target=self.private_execute(context))
        th.start()
        return {'FINISHED'}

class OpenWebInterfaceOperator(bpy.types.Operator):
    bl_idname = '3dai.open_web_interface_operator'
    bl_label = 'Open Web Interface'

    def private_execute(self):
        print('Opening web interface')
        webbrowser.open('https://d-ai-365820.web.app/')

    def execute(self, context):
        th = Thread(target=self.private_execute)
        th.start()
        return {'FINISHED'}